const cloud = require('@cloudbase/node-sdk');

const app = cloud.init({ env: cloud.SYMBOL_CURRENT_ENV });
const db = app.database();
const _ = db.command;

async function verifyUserToken(token, expectedUserId) {
  if (!token || typeof token !== 'string') {
    return { code: 401, message: '缺少有效 token' };
  }

  const result = await db.collection('users')
    .where({
      token,
      tokenExpireAt: _.gte(new Date()),
      status: 'active'
    })
    .limit(1)
    .get();

  if (!result.data || result.data.length === 0) {
    return { code: 401, message: '登录已过期，请重新登录' };
  }

  const user = result.data[0];
  if (expectedUserId && String(user._id) !== String(expectedUserId)) {
    return { code: 403, message: '用户身份校验失败' };
  }

  return { code: 0, user };
}

exports.main = async (event) => {
  const { token, userId } = event;

  try {
    const auth = await verifyUserToken(token, userId);
    if (auth.code !== 0) {
      return auth;
    }

    const result = await db.collection('cloud_profiles')
      .where({ userId: auth.user._id })
      .orderBy('updatedAt', 'desc')
      .limit(200)
      .get();

    const profiles = (result.data || []).map((item) => ({
      id: item._id,
      profileId: item.profileId,
      profileName: item.profileName,
      examCount: item.examCount || 0,
      dataSize: item.dataSize || 0,
      lastSyncAt: item.lastSyncAt || item.updatedAt || item.createdAt || null,
      createdAt: item.createdAt || null,
      updatedAt: item.updatedAt || null
    }));

    return {
      code: 0,
      data: profiles
    };
  } catch (error) {
    console.error('[listCloudProfiles] error:', error);
    return { code: 500, message: '读取云端档案失败：' + (error.message || '未知错误') };
  }
};
