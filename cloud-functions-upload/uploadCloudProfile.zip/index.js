const cloud = require('@cloudbase/node-sdk');

const app = cloud.init({ env: cloud.SYMBOL_CURRENT_ENV });
const db = app.database();
const _ = db.command;

async function verifyUserToken(token, expectedUserId) {
  if (!token || typeof token !== 'string') {
    return { code: 401, message: '缺少有效 token' };
  }

  const result = await db.collection('users')
    .where({
      token,
      tokenExpireAt: _.gte(new Date()),
      status: 'active'
    })
    .limit(1)
    .get();

  if (!result.data || result.data.length === 0) {
    return { code: 401, message: '登录已过期，请重新登录' };
  }

  const user = result.data[0];
  if (expectedUserId && String(user._id) !== String(expectedUserId)) {
    return { code: 403, message: '用户身份校验失败' };
  }

  return { code: 0, user };
}

exports.main = async (event) => {
  const { token, userId, profileId, profileName, profileData, examCount, dataSize } = event;

  if (!profileId || typeof profileId !== 'string') {
    return { code: 400, message: '缺少 profileId' };
  }
  if (!profileName || typeof profileName !== 'string') {
    return { code: 400, message: '缺少档案名称' };
  }
  if (!profileData || typeof profileData !== 'object') {
    return { code: 400, message: '缺少档案数据' };
  }

  try {
    const auth = await verifyUserToken(token, userId);
    if (auth.code !== 0) {
      return auth;
    }

    const now = new Date();
    const normalizedExamCount = Number.isFinite(Number(examCount)) ? Number(examCount) : 0;
    const normalizedDataSize = Number.isFinite(Number(dataSize)) ? Number(dataSize) : 0;

    const existing = await db.collection('cloud_profiles')
      .where({
        userId: auth.user._id,
        profileId
      })
      .limit(1)
      .get();

    if (existing.data && existing.data.length > 0) {
      const current = existing.data[0];
      await db.collection('cloud_profiles').doc(current._id).update({
        profileName,
        profileData,
        examCount: normalizedExamCount,
        dataSize: normalizedDataSize,
        lastSyncAt: now,
        updatedAt: now
      });

      return {
        code: 0,
        message: '云端档案已更新',
        data: {
          id: current._id,
          profileId,
          lastSyncAt: now.toISOString()
        }
      };
    }

    const createResult = await db.collection('cloud_profiles').add({
      userId: auth.user._id,
      profileId,
      profileName,
      profileData,
      examCount: normalizedExamCount,
      dataSize: normalizedDataSize,
      lastSyncAt: now,
      createdAt: now,
      updatedAt: now
    });

    return {
      code: 0,
      message: '云端档案已创建',
      data: {
        id: createResult.id,
        profileId,
        lastSyncAt: now.toISOString()
      }
    };
  } catch (error) {
    console.error('[uploadCloudProfile] error:', error);
    return { code: 500, message: '上传云端档案失败：' + (error.message || '未知错误') };
  }
};
